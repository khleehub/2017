gradle clean
gradle build
gradle jettyRun
gradle jettyRunWar