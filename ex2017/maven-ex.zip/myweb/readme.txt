mvn clean
mvn package
mvn jetty:run
mvn tomcat7:run